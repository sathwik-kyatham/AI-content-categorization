"""Algorithm interfaces corresponding to Section 4.4 of the design document.

These are lightweight, real, runnable scikit-learn classifiers standing in
conceptually for:

  Algorithm A (classical):        TF-IDF/HOG + SVM/Random Forest
  Algorithm B (deep multimodal):  CNN/ViT + Transformer, shared CLIP-style embedding
  Algorithm C (deep single-modal): media-type-specific deep model, no shared embedding

The point of this module is to keep the *pipeline shape* faithful to the
design (fit on train features, predict on held-out features) so that
swapping in real models later is a drop-in replacement — not to claim these
toy classifiers are actually competitive deep learning systems.
"""

from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler

from preprocessing import classical_features, deep_features


class AlgorithmA:
    """Classical feature-engineered pipeline (baseline)."""
    name = "A_classical"

    def __init__(self):
        self.scaler = StandardScaler()
        self.clf = SVC(kernel="rbf", C=2.0, probability=True, random_state=42)

    def featurize(self, items):
        return [classical_features(it) for it in items]

    def fit(self, items, labels):
        X = self.featurize(items)
        X = self.scaler.fit_transform(X)
        self.clf.fit(X, labels)
        return self

    def predict(self, items):
        X = self.featurize(items)
        X = self.scaler.transform(X)
        return self.clf.predict(X)


class AlgorithmB:
    """Deep multimodal transformer pipeline (shared embedding space across
    media types) — simulated here as an MLP over the richer 'deep_features'
    representation, shared across media types."""
    name = "B_multimodal_deep"

    def __init__(self):
        self.scaler = StandardScaler()
        self.clf = MLPClassifier(hidden_layer_sizes=(64, 32), max_iter=800, random_state=42)

    def featurize(self, items):
        return [deep_features(it) for it in items]

    def fit(self, items, labels):
        X = self.featurize(items)
        X = self.scaler.fit_transform(X)
        self.clf.fit(X, labels)
        return self

    def predict(self, items):
        X = self.featurize(items)
        X = self.scaler.transform(X)
        return self.clf.predict(X)


class AlgorithmC:
    """Deep, single-modality model (ablation): same 'deep_features' as
    Algorithm B, but trained separately per media type with no shared
    embedding space, isolating the contribution of the shared multimodal
    representation (Section 4.4.3)."""
    name = "C_singlemodal_deep"

    def __init__(self):
        self.models = {}  # media_type -> (scaler, clf)

    def fit(self, items, labels):
        by_media = {}
        for it, y in zip(items, labels):
            by_media.setdefault(it.media_type, ([], []))
            by_media[it.media_type][0].append(it)
            by_media[it.media_type][1].append(y)

        for media_type, (media_items, media_labels) in by_media.items():
            scaler = StandardScaler()
            clf = RandomForestClassifier(n_estimators=200, random_state=42)
            X = [deep_features(it) for it in media_items]
            X = scaler.fit_transform(X)
            clf.fit(X, media_labels)
            self.models[media_type] = (scaler, clf)
        return self

    def predict(self, items):
        preds = [None] * len(items)
        by_media_idx = {}
        for i, it in enumerate(items):
            by_media_idx.setdefault(it.media_type, []).append(i)

        for media_type, idxs in by_media_idx.items():
            scaler, clf = self.models[media_type]
            X = [deep_features(items[i]) for i in idxs]
            X = scaler.transform(X)
            preds_for_media = clf.predict(X)
            for i, pred in zip(idxs, preds_for_media):
                preds[i] = pred
        return preds


def build_algorithm(name: str):
    return {"A_classical": AlgorithmA, "B_multimodal_deep": AlgorithmB,
            "C_singlemodal_deep": AlgorithmC}[name]()
