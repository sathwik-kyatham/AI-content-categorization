"""Media-type-specific preprocessing, mirroring Section 4.3 of the design
document. In this simulation, both "classical" and "deep" feature extractors
are simple linear projections of the same synthetic raw_signal, since there
is no real pixel/audio/text data to process. Replace the body of each
function with real feature extraction when wiring in actual media:

  - classical_features(image):  color histogram + HOG + SIFT-BoVW
  - deep_features(image):       normalized pixel tensor for a CNN/ViT backbone
  - classical_features(video):  per-frame HOG/color, averaged + optical flow
  - deep_features(video):       16-frame tensor for a temporal-attention encoder
  - classical_features(text):   TF-IDF (unigram+bigram)
  - deep_features(text):        subword tokens for a transformer encoder
"""

import numpy as np


def classical_features(item, seed_offset: int = 0) -> np.ndarray:
    """Simulates a lossy, hand-crafted feature extractor: a fixed random
    linear projection to a smaller dimension, which necessarily discards
    some information relative to the raw signal (and discards *more* for
    video, matching the design doc's expectation that classical pipelines
    lose the most on video due to missing temporal modeling)."""
    rng = np.random.default_rng(1000 + seed_offset)
    dim_out = 12
    proj = rng.normal(0, 1, size=(dim_out, item.raw_signal.shape[0]))
    features = proj @ item.raw_signal

    if item.media_type == "video":
        # Simulate loss of temporal structure via extra feature-dropping noise.
        features = features + rng.normal(0, 1.2, size=features.shape)
    return features


def deep_features(item, seed_offset: int = 0) -> np.ndarray:
    """Simulates a higher-fidelity, learned feature extractor: a larger,
    less lossy linear projection with less added noise, standing in for a
    pretrained CNN/ViT/Transformer/CLIP-style encoder."""
    rng = np.random.default_rng(2000 + seed_offset)
    dim_out = 24
    proj = rng.normal(0, 1, size=(dim_out, item.raw_signal.shape[0]))
    features = proj @ item.raw_signal
    features = features + rng.normal(0, 0.4, size=features.shape)
    return features
