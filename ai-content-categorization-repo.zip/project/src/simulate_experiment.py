"""End-to-end runner tying together data_simulation -> algorithms -> evaluate,
matching the pipeline described in the design document. Produces:

  results/metrics_summary.csv    per (algorithm, media_type) accuracy/macro-F1
  results/confusion_matrices.json  full confusion matrices per algorithm/media type
  results/significance_tests.json  pairwise McNemar's test results

Run with: python src/simulate_experiment.py
"""

import json
import csv
import os

from config import ALGORITHMS, MEDIA_TYPES, SPLIT_RATIOS, RANDOM_SEED
from data_simulation import generate_dataset, split_dataset
from algorithms import build_algorithm
from evaluate import compute_metrics, mcnemar_test, class_balance

RESULTS_DIR = os.path.join(os.path.dirname(__file__), "..", "results")


def run():
    os.makedirs(RESULTS_DIR, exist_ok=True)

    print("Generating synthetic dataset...")
    items = generate_dataset(seed=RANDOM_SEED)
    train, val, test = split_dataset(items, SPLIT_RATIOS, seed=RANDOM_SEED)
    print(f"  train={len(train)} val={len(val)} test={len(test)}")
    print(f"  test class balance: {class_balance([it.category for it in test])}")

    y_train = [it.category for it in train]
    y_test = [it.category for it in test]

    predictions = {}
    summary_rows = []
    confusion_output = {}

    for algo_name in ALGORITHMS:
        print(f"Fitting {algo_name}...")
        model = build_algorithm(algo_name)
        model.fit(train, y_train)
        preds = model.predict(test)
        predictions[algo_name] = preds

        overall = compute_metrics(y_test, preds)
        confusion_output[algo_name] = {
            "overall": {
                "labels": overall["confusion_matrix_labels"],
                "matrix": overall["confusion_matrix"],
            }
        }
        summary_rows.append({
            "algorithm": algo_name,
            "media_type": "ALL",
            "accuracy": round(overall["accuracy"], 4),
            "macro_f1": round(overall["macro_f1"], 4),
        })

        # Per-media-type breakdown, matching Section 6's expected-outcomes table.
        for media_type in MEDIA_TYPES:
            idxs = [i for i, it in enumerate(test) if it.media_type == media_type]
            y_true_mt = [y_test[i] for i in idxs]
            y_pred_mt = [preds[i] for i in idxs]
            m = compute_metrics(y_true_mt, y_pred_mt)
            summary_rows.append({
                "algorithm": algo_name,
                "media_type": media_type,
                "accuracy": round(m["accuracy"], 4),
                "macro_f1": round(m["macro_f1"], 4),
            })
            confusion_output[algo_name][media_type] = {
                "labels": m["confusion_matrix_labels"],
                "matrix": m["confusion_matrix"],
            }

    # Pairwise significance tests (Section 5.1)
    significance = {}
    algo_pairs = [("A_classical", "B_multimodal_deep"),
                  ("A_classical", "C_singlemodal_deep"),
                  ("C_singlemodal_deep", "B_multimodal_deep")]
    for a, b in algo_pairs:
        significance[f"{a}_vs_{b}"] = mcnemar_test(y_test, predictions[a], predictions[b])

    # Write outputs
    summary_path = os.path.join(RESULTS_DIR, "metrics_summary.csv")
    with open(summary_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["algorithm", "media_type", "accuracy", "macro_f1"])
        writer.writeheader()
        writer.writerows(summary_rows)

    with open(os.path.join(RESULTS_DIR, "confusion_matrices.json"), "w") as f:
        json.dump(confusion_output, f, indent=2)

    with open(os.path.join(RESULTS_DIR, "significance_tests.json"), "w") as f:
        json.dump(significance, f, indent=2)

    print(f"\nWrote results to {os.path.abspath(RESULTS_DIR)}/")
    print("\n--- Summary (accuracy / macro-F1) ---")
    for row in summary_rows:
        print(f"  {row['algorithm']:<20} {row['media_type']:<8} "
              f"acc={row['accuracy']:.3f}  macroF1={row['macro_f1']:.3f}")


if __name__ == "__main__":
    run()
