"""Evaluation metrics corresponding to Section 5 of the design document:
accuracy, per-class and macro precision/recall/F1, confusion matrix, and a
paired McNemar's test for comparing two algorithms' correctness patterns on
the same test items.
"""

from collections import Counter
import numpy as np
from sklearn.metrics import (
    accuracy_score, precision_recall_fscore_support, confusion_matrix,
)

from config import CATEGORIES


def compute_metrics(y_true, y_pred) -> dict:
    accuracy = accuracy_score(y_true, y_pred)
    precision, recall, f1, support = precision_recall_fscore_support(
        y_true, y_pred, labels=CATEGORIES, zero_division=0
    )
    macro_f1 = float(np.mean(f1))
    per_class = {
        cat: {
            "precision": float(precision[i]),
            "recall": float(recall[i]),
            "f1": float(f1[i]),
            "support": int(support[i]),
        }
        for i, cat in enumerate(CATEGORIES)
    }
    cm = confusion_matrix(y_true, y_pred, labels=CATEGORIES).tolist()

    return {
        "accuracy": float(accuracy),
        "macro_f1": macro_f1,
        "per_class": per_class,
        "confusion_matrix": cm,
        "confusion_matrix_labels": CATEGORIES,
    }


def mcnemar_test(y_true, pred_a, pred_b) -> dict:
    """Paired McNemar's test comparing whether algorithm A and algorithm B
    disagree asymmetrically in who gets an item right, per Section 5.1's
    statistical-significance requirement. Uses the chi-square approximation
    (valid when b + c, the discordant-pair count, is not tiny)."""
    correct_a = [a == t for a, t in zip(pred_a, y_true)]
    correct_b = [b == t for b, t in zip(pred_b, y_true)]

    b_count = sum(1 for ca, cb in zip(correct_a, correct_b) if ca and not cb)  # A right, B wrong
    c_count = sum(1 for ca, cb in zip(correct_a, correct_b) if not ca and cb)  # B right, A wrong

    n_discordant = b_count + c_count
    if n_discordant == 0:
        stat, p_value = 0.0, 1.0
    else:
        stat = (abs(b_count - c_count) - 1) ** 2 / n_discordant  # continuity-corrected
        # chi-square with 1 dof; use survival function without importing scipy
        p_value = _chi2_sf_1dof(stat)

    return {
        "a_right_b_wrong": b_count,
        "b_right_a_wrong": c_count,
        "statistic": stat,
        "p_value": p_value,
        "significant_at_0.05": p_value < 0.05,
    }


def _chi2_sf_1dof(x: float) -> float:
    """Survival function of chi-square with 1 degree of freedom, computed
    via the complementary error function (avoids a scipy dependency)."""
    import math
    return math.erfc(math.sqrt(x / 2))


def class_balance(labels) -> dict:
    counts = Counter(labels)
    total = sum(counts.values())
    return {cat: counts.get(cat, 0) / total for cat in CATEGORIES}
