"""Generates a synthetic labeled dataset that mimics the structure described
in the experimental design document (Section 4.2), without requiring any
real media files. Each synthetic "item" is a feature vector plus metadata
(media_type, category) so the rest of the pipeline (preprocessing,
algorithms, evaluation) can be exercised end-to-end.

Swap this module out for a real data loader (reading from `data/`) once
actual labeled media is available — nothing else in the pipeline needs to
change as long as the returned schema is preserved.
"""

from dataclasses import dataclass, field
import numpy as np

from config import CATEGORIES, MEDIA_TYPES, CLASS_WEIGHTS, ITEMS_PER_MEDIA_TYPE, RANDOM_SEED


@dataclass
class MediaItem:
    item_id: str
    media_type: str
    category: str
    # Latent "semantic signal" — a stand-in for real pixel/audio/text content.
    # Each category gets a distinct latent center so a classifier has something
    # non-trivial, but noisy, to learn from.
    raw_signal: np.ndarray = field(repr=False)


def _category_centers(dim: int, seed: int) -> dict:
    rng = np.random.default_rng(seed)
    return {cat: rng.normal(0, 1.5, size=dim) for cat in CATEGORIES}


def generate_dataset(items_per_media_type: int = ITEMS_PER_MEDIA_TYPE,
                      signal_dim: int = 32,
                      seed: int = RANDOM_SEED) -> list[MediaItem]:
    """Returns a flat list of MediaItem, balanced per CLASS_WEIGHTS within
    each media type."""
    rng = np.random.default_rng(seed)
    centers = _category_centers(signal_dim, seed)

    items = []
    counter = 0
    for media_type in MEDIA_TYPES:
        cats = list(CLASS_WEIGHTS.keys())
        weights = np.array(list(CLASS_WEIGHTS.values()))
        weights = weights / weights.sum()
        assigned_categories = rng.choice(cats, size=items_per_media_type, p=weights)

        # Video is modeled as noisier / harder to separate (temporal info lost
        # unless an algorithm explicitly models it), matching the design doc's
        # expectation that classical pipelines underperform most on video.
        noise_scale = {"image": 1.0, "video": 1.6, "text": 0.8}[media_type]

        for cat in assigned_categories:
            noise = rng.normal(0, noise_scale, size=signal_dim)
            signal = centers[cat] + noise
            items.append(MediaItem(
                item_id=f"{media_type}_{counter:06d}",
                media_type=media_type,
                category=cat,
                raw_signal=signal,
            ))
            counter += 1

    rng.shuffle(items)
    return items


def split_dataset(items: list[MediaItem], ratios: dict, seed: int = RANDOM_SEED):
    """Stratified split by (media_type, category) so every split has
    representative coverage, matching Section 4.1 of the design doc."""
    rng = np.random.default_rng(seed)
    buckets: dict[tuple, list[MediaItem]] = {}
    for item in items:
        key = (item.media_type, item.category)
        buckets.setdefault(key, []).append(item)

    train, val, test = [], [], []
    for key, bucket in buckets.items():
        bucket = list(bucket)
        rng.shuffle(bucket)
        n = len(bucket)
        n_train = int(n * ratios["train"])
        n_val = int(n * ratios["val"])
        train.extend(bucket[:n_train])
        val.extend(bucket[n_train:n_train + n_val])
        test.extend(bucket[n_train + n_val:])

    return train, val, test


if __name__ == "__main__":
    data = generate_dataset()
    tr, va, te = split_dataset(data, {"train": 0.7, "val": 0.1, "test": 0.2})
    print(f"Generated {len(data)} items -> train={len(tr)} val={len(va)} test={len(te)}")
