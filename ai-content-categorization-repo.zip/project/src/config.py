"""Shared configuration for the content-categorization experiment."""

RANDOM_SEED = 42

CATEGORIES = [
    "News",
    "Entertainment",
    "Sports",
    "Technology",
    "Lifestyle",
    "Sensitive_Restricted",
]

MEDIA_TYPES = ["image", "video", "text"]

# Approximate class balance matching the design doc (Sensitive_Restricted under-represented)
CLASS_WEIGHTS = {
    "News": 0.18,
    "Entertainment": 0.18,
    "Sports": 0.18,
    "Technology": 0.18,
    "Lifestyle": 0.18,
    "Sensitive_Restricted": 0.10,
}

SPLIT_RATIOS = {"train": 0.70, "val": 0.10, "test": 0.20}

ITEMS_PER_MEDIA_TYPE = 2000  # kept small for a fast local simulation; design doc specifies 10,000

ALGORITHMS = ["A_classical", "B_multimodal_deep", "C_singlemodal_deep"]
